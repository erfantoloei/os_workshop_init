#include "co.h"
#include "ch.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdatomic.h>
#include <signal.h>     
#include <pthread.h>    


channel_t *ch;

void producer() {
    for (int i = 0; i < 50; i++) {
        printf("Producer: Sending %d\n", i);
        channel_send(ch, (void *)(long)i);
        sleep(1);
    }
}

void consumer() {
    for (int i = 0; i < 50; i++) {
        int data = (int)(long)channel_recv(ch);
        printf("Consumer: Received %d\n", data);
    }
}
int wait_sig() {
    sigset_t set;
    int sig;

    sigemptyset(&set);
    sigaddset(&set, SIGINT);
    sigaddset(&set, SIGTERM);
    sigaddset(&set, SIGHUP);

    if (pthread_sigmask(SIG_BLOCK, &set, NULL) != 0) {
        perror("pthread_sigmask");
        return -1;
    }

    if (sigwait(&set, &sig) != 0) {
        perror("sigwait");
        return -1;
    }

    printf("Received signal: %d\n", sig);
    return sig;
}

int main() {
    co_init();
    
    ch = make_ch();
    co(producer, NULL);
    co(consumer, NULL);
    
    int sig = wait_sig();
    co_shutdown();
    return sig;
}
