#include "co.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdatomic.h>
#include <signal.h>
#include <pthread.h>
#include <assert.h>

#ifdef __linux__
#include <sys/prctl.h>
#else
#include <signal.h>
#endif

#define MAX_TASKS 128

static pthread_t threads[MAX_TASKS];
static atomic_int task_count = 0;

void co_init() {
    atomic_store(&task_count, 0);
    printf("co initialized\n");
}

void co_shutdown() {
    for (int i = 0; i < atomic_load(&task_count); i++) {
        pthread_join(threads[i], NULL);
    }
    printf("co shutdown complete\n");
}

typedef struct {
    task_func_t func;
    void *arg;
} task_wrapper_t;

static void *task_entry(void *arg) {
    task_wrapper_t *tw = (task_wrapper_t *)arg;
    tw->func(tw->arg);
    free(tw); 
    return NULL;
}

void co(task_func_t func, void *arg) {
    int idx = atomic_fetch_add(&task_count, 1);
    assert(idx < MAX_TASKS && "Too many tasks!");

    task_wrapper_t *tw = malloc(sizeof(task_wrapper_t));
    tw->func = func;
    tw->arg = arg;

    pthread_create(&threads[idx], NULL, task_entry, tw);
}
