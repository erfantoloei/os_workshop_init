#include "co.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdatomic.h>
#include <signal.h>
#include <pthread.h>

#ifdef __linux__
#include <sys/prctl.h>
#else
#endif

void get_thread_name(char* name) {
#ifdef __linux__
    prctl(PR_GET_NAME, name, 0, 0, 0);
#else

#endif
}

void hello(void *a) {
    int aint = *(int *)a;
    char thread_name[32] = "unknown";
    get_thread_name(thread_name);
    printf("[%s] -> Hello from coroutine %d\n", thread_name, aint);
}

int wait_sig() {
    sigset_t set;
    int sig;

    sigemptyset(&set);
    sigaddset(&set, SIGINT);
    sigaddset(&set, SIGTERM);
    sigaddset(&set, SIGHUP);

    if (pthread_sigmask(SIG_BLOCK, &set, NULL) != 0) {
        perror("pthread_sigmask");
        return -1;
    }

    if (sigwait(&set, &sig) != 0) {
        perror("sigwait");
        return -1;
    }

    printf("Received signal: %d\n", sig);
    return sig;
}

int main() {
    co_init();

    int a = 1;
    for (int i = 0; i < 100; i++) {
        co(hello, (void *) &a);    
    }
    
    int sig = wait_sig();
    co_shutdown();
    return sig;
}
