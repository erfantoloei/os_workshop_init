# Os Workshop

We want to implement a csp like concurrency model in c programming language. Inspired by golang implemetation.

# Run examples
```
- make co_example # (How co(routines) working)
- make ch_example # (How ch(annels) working)
```